// var express = require('express');
// var app = express();
// var cors =require('cors')
// var bodyParser = require('body-parser');
// import mysql from "mysql";
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({
//     extended: true
// }));
// app.use(cors())
// app.get('/', function (req, res) {
//     return res.send({ error: true, message: 'hello' })
// });
// var dbConn = mysql.createConnection({
//     host: 'localhost',
//     user: 'root',
//     password: 'vertrigo',
//     database: 'lixiweb'
// });
// dbConn.connect();
// app.get('/show', function (req, res) {
//     dbConn.query('SELECT * FROM lixi',  function (error, results, fields) {
//         if (error) throw error;
//         return res.send({ error: false, data: results[0], message: 'users list.' });
//     });
// });
// app.post('/insert', function (req, res) {
//     let user = req.body.sotaikhoan;
//     if (!user) {
//         return res.status(400).send({ error:true, message: 'Please provide user' });
//     }

// app.listen(5000, function () {
//     console.log('Node app is running on port 5000');
// });
import express from 'express'
import cors from 'cors'
import mysql from 'mysql'
import bodyParser from 'body-parser'
const app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(cors())
app.get('/', function (req, res) {
    return res.send({ error: true, message: 'hello' })
});
const dbConn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'vertrigo',
    database: 'lixiweb'
});
dbConn.connect();
app.get('/show', function (req, res) {
    dbConn.query('SELECT * FROM lixidb WHERE is_open = "0"',  function (error, results, fields) {
        if (error) throw error;
        return res.send({ error: false, data: results, message: 'users list.' });
    });
});
app.put('/insert', function (req, res) {
    let user = ['1',req.body.tennganhang,req.body.sotaikhoan,req.body.sotiennhan,req.body.path]
    if (!user) {
        return res.status(400).send({ error:true, message: 'Please provide user' });
    }
    var sql = "UPDATE lixidb SET `is_open` = ?,`tennganhang`=?,`sotaikhoan`=?,`sotiennhan`=? WHERE path = ?"
    dbConn.query(sql,user, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
    });
  });
app.listen(5000, function () {
    console.log('Node app is running on port 5000');
});